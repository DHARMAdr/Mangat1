/* MangaFlow TRANSLATE tests (round 32). Run:  node test/translate.test.js   (needs the playwright package; uses the mock server in server.js)
   WHY: the Translate add-on (translate.js + the ocr/ folder) is new in round 32 and must not break anything old. These checks press the real button in a real
        browser, read a real picture with the real text reader (WebAssembly), and use a FAKE translation service (the real ones need the internet), so the test is repeatable.
   WHAT the fake does: every request to translate.googleapis.com is answered with  "TR[<hi/en>]: <the original words>"  so the checks can see which words were sent and into which language.
   The picture used by the mock chapters is test/page.jpg: three speech bubbles, two in English and one in Japanese (made with a font, so it is clean text).
   IMPROVE: add a vertical-Japanese page and a Korean page to the test folder, and check the groups the reader makes for them. */
const { chromium } = (() => { try { return require('playwright'); } catch { return require('/opt/npm-tools/node_modules/playwright'); } })();
const { start } = require('./server');
const PORT = 8765, BASE = 'http://127.0.0.1:' + PORT + '/';
const results = []; const check = (name, ok, extra) => { results.push({ name, ok: !!ok }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra && !ok ? '   -> ' + extra : '')); };
const SETTINGS = { proxies: ['http://127.0.0.1:' + PORT + '/proxy?url={url}'], ver: 12, searchEngine: 'google', googleKey: '', trFrom: 'eng', trEngine: 'google', trTo: 'en', preloadAhead: 0 };

(async () => {
  await start(PORT);
  const browser = await chromium.launch();
  async function open(opts = {}) {
    const ctx = await browser.newContext({ viewport: opts.viewport || { width: 1280, height: 800 }, hasTouch: !!opts.touch, isMobile: !!opts.touch });
    await ctx.addInitScript(s => { if (!localStorage.getItem('mf_settings')) localStorage.setItem('mf_settings', JSON.stringify(s)); }, { ...SETTINGS, ...(opts.settings || {}) });
    const asked = []; ctx.asked = asked;
    await ctx.route('https://translate.googleapis.com/**', r => {
      const u = new URL(r.request().url()), q = u.searchParams.get('q') || '', tl = u.searchParams.get('tl'); asked.push({ q, tl, sl: u.searchParams.get('sl') });
      r.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify([[['TR[' + tl + ']: ' + q, q]], null, u.searchParams.get('sl')]) });
    });
    await ctx.route('https://cse.google.com/**', r => r.fulfill({ status: 200, contentType: 'text/javascript', body: '' }));
    if (opts.route) await opts.route(ctx);
    const page = await ctx.newPage(); const errs = [], csp = [];
    page.on('pageerror', e => errs.push(e.message));
    page.on('console', m => { if (/Content Security Policy|Refused to/i.test(m.text())) csp.push(m.text().slice(0, 200)); });
    await page.goto(BASE); await page.waitForSelector('#start .hero');
    return { ctx, page, errs, csp };
  }
  async function read(page, url) {
    await page.fill('#addrHero', url || 'https://mock.test/manga/demo/chapter-2/'); await page.press('#addrHero', 'Enter');
    await page.waitForSelector('body.reading'); await page.waitForSelector('#stream img.page.loaded', { timeout: 30000 });
  }
  const layers = page => page.evaluate(() => document.querySelectorAll('.mf-tr-layer').length);
  const bubbles = page => page.evaluate(() => Array.from(document.querySelectorAll('.mf-tr-b span')).map(s => s.textContent));
  const waitBubbles = (page, n, ms) => page.waitForFunction(k => document.querySelectorAll('.mf-tr-b').length >= k, n, { timeout: ms || 120000 });

  // ---------------------------------------------------------------- A. the file, the button, the Settings tab
  { const { ctx, page, errs } = await open();
    check('T1 translate.js is linked and the add-on announces itself', await page.evaluate(() => !!window.MangaFlowTranslate && window.MangaFlowTranslate.version === 1));
    check('T2 the round button is hidden on the start page', await page.evaluate(() => getComputedStyle(document.getElementById('mfTr')).display === 'none'));
    check('T3 no-tr-file is NOT set (the file is linked), so the Settings tab is visible', await page.evaluate(() => !document.body.classList.contains('no-tr-file')));
    await page.click('#btnSettings'); await page.click('#setTabs [data-tab=translate]').catch(() => {});
    const tab = await page.evaluate(() => { const t = document.querySelector('#setTabs [data-tab=translate]'); return !!t && getComputedStyle(t).display !== 'none'; });
    check('T4 Settings has a Translate tab', tab || await page.evaluate(() => !!document.querySelector('#trBox')));
    check('T5 the language lists are filled (30 languages to translate into, 6 page languages)', await page.evaluate(() => document.querySelectorAll('#setTrTo option').length >= 28 && document.querySelectorAll('#setTrFrom option').length === 6));
    check('T6 the saved values are shown (English, English pages, Google)', await page.evaluate(() => document.getElementById('setTrTo').value === 'en' && document.getElementById('setTrFrom').value === 'eng' && document.getElementById('setTrEngine').value === 'google'));
    await page.evaluate(() => { const e = document.getElementById('setTrTo'); e.value = 'hi'; e.dispatchEvent(new Event('change', { bubbles: true })); });
    check('T7 choosing Hindi in Settings is saved', await page.evaluate(() => JSON.parse(localStorage.getItem('mf_settings')).trTo === 'hi'));
    check('T8 no script error on the start page', errs.length === 0, errs.join(' | '));
    await ctx.close(); }

  // ---------------------------------------------------------------- B. the pure parts (no picture needed)
  { const { ctx, page } = await open();
    const r = await page.evaluate(() => {
      const t = window.MangaFlowTranslate._test, L = (x0, y0, x1, y1, text, conf) => ({ x0, y0, x1, y1, text, conf: conf || 90 });
      const two = t.groupLines([L(100, 100, 400, 130, 'WHERE ARE YOU'), L(100, 140, 380, 170, 'GOING?')]);                         // two lines of one bubble
      const apart = t.groupLines([L(100, 100, 400, 130, 'FIRST BUBBLE'), L(100, 600, 400, 630, 'SECOND BUBBLE')]);              // two bubbles far apart
      const vert = t.groupLines([L(300, 100, 334, 350, 'どこへ行くの'), L(250, 100, 284, 400, 'こんな遅い時間に')]);                     // two vertical columns: right column first
      return { two: two.length + ':' + two[0].text, apart: apart.length, vert: vert.length + ':' + vert[0].text,
        tidyJp: t.tidy('どこ へ 行く の ?'), tidyEn: t.tidy('WHERE   ARE YOU'), noise: t.usable({ text: '..', conf: 95 }, 50), good: t.usable({ text: 'HELLO', conf: 80 }, 50), low: t.usable({ text: 'HELLO', conf: 20 }, 50),
        gKo: t.guessLang('어디 가는 거야'), gJa: t.guessLang('どこへ行くの'), gEn: t.guessLang('WHERE ARE YOU'), gZh: t.guessLang('你要去哪里') };
    });
    check('T9 two close lines become ONE bubble, in reading order', r.two === '1:WHERE ARE YOU GOING?', r.two);
    check('T10 two far-apart lines stay two bubbles', r.apart === 2, r.apart);
    check('T11 vertical Japanese columns join right column first, without spaces', r.vert === '1:どこへ行くのこんな遅い時間に', r.vert);
    check('T12 tidy(): no spaces between kana, one space between English words', r.tidyJp === 'どこへ行くの?' && r.tidyEn === 'WHERE ARE YOU', r.tidyJp + ' | ' + r.tidyEn);
    check('T13 noise and low scores are dropped, real words kept', r.noise === false && r.good === true && r.low === false);
    check('T14 language guess: Korean, Japanese, English, Chinese', r.gKo === 'kor' && r.gJa === 'jpn' && r.gEn === 'eng' && r.gZh === 'chi_sim', JSON.stringify(r));
    await ctx.close(); }

  // ---------------------------------------------------------------- C. the whole way: button -> reading the picture -> fake translation -> boxes
  { const { ctx, page, errs, csp } = await open();
    await read(page);
    check('T15 in reading mode the button is shown and starts switched OFF', await page.evaluate(() => { const b = document.getElementById('mfTr'); return getComputedStyle(b).display !== 'none' && !b.classList.contains('on') && b.getAttribute('aria-pressed') === 'false'; }));
    check('T16 nothing is read or translated while the button is off', await layers(page) === 0 && ctx.asked.length === 0);
    const srcBefore = await page.evaluate(() => document.querySelector('#stream img.page').src);
    await page.click('#mfTr');
    check('T17 pressing the button switches it on and shows the status bar', await page.evaluate(() => document.getElementById('mfTr').classList.contains('on') && document.body.classList.contains('mf-tr-on') && getComputedStyle(document.getElementById('mfTrBar')).display !== 'none'));
    let got = true; try { await waitBubbles(page, 2); } catch { got = false; }
    check('T18 the words in the picture are read and boxes appear (2 English bubbles)', got, 'status: ' + await page.evaluate(() => document.getElementById('mfTrMsg').textContent));
    const texts = await bubbles(page);
    check('T19 each box carries the translated text of its bubble', texts.some(t => /(?:TR\[en\]: )?WHERE ARE YOU GOI/.test(t)) && texts.some(t => /(?:TR\[en\]: )?.*FOLLOW M/.test(t)), JSON.stringify(texts.slice(0, 4)));
    check('T20 the service was asked with the right languages (from English, into English is skipped, so Hindi is tested later)', ctx.asked.length === 0 || ctx.asked.every(a => a.tl === 'en'), JSON.stringify(ctx.asked.slice(0, 2)));
    const geo = await page.evaluate(() => { const l = document.querySelector('.mf-tr-layer'), im = l._img, a = l.getBoundingClientRect(), b = im.getBoundingClientRect(); const bx = Array.from(l.children).map(c => c.getBoundingClientRect());
      return { same: Math.abs(a.left - b.left) < 2 && Math.abs(a.top - b.top) < 2 && Math.abs(a.width - b.width) < 2 && Math.abs(a.height - b.height) < 2, inside: bx.every(r => r.left >= a.left - 1 && r.right <= a.right + 1 && r.top >= a.top - 1 && r.bottom <= a.bottom + 1), n: bx.length, fits: Array.from(l.children).every(c => c.firstChild.offsetHeight <= c.clientHeight + 1) }; });
    check('T21 the layer sits exactly on its picture and every box is inside it', geo.same && geo.inside && geo.n >= 2, JSON.stringify(geo));
    check('T22 the new text fits inside every box', geo.fits, JSON.stringify(geo));
    check('T23 a box has the colour of the bubble behind it (light) and dark text', await page.evaluate(() => { const b = document.querySelector('.mf-tr-b'), cs = getComputedStyle(b); const m = cs.backgroundColor.match(/\d+/g).map(Number); return m[0] > 200 && m[1] > 200 && m[2] > 200 && /^rgb\((17|0), ?(17|0)/.test(cs.color); }));
    check('T24 the original picture is untouched (same address, no canvas written into it)', await page.evaluate(s => document.querySelector('#stream img.page').src === s, srcBefore));
    // tapping a box: peek, and no scroll
    const y0 = await page.evaluate(() => scrollY); await page.evaluate(() => document.querySelector('.mf-tr-b').scrollIntoView({ block: 'center' })); const y1 = await page.evaluate(() => scrollY);
    await page.mouse.click(...(await page.evaluate(() => { const r = document.querySelector('.mf-tr-b').getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; })));
    await page.waitForTimeout(150);
    check('T25 tapping a box lets the original show through (peek) and does not scroll the page', await page.evaluate(() => !!document.querySelector('.mf-tr-b.peek')) && Math.abs((await page.evaluate(() => scrollY)) - y1) < 4, 'y ' + y0 + '/' + y1);
    // off and on again
    await page.evaluate(() => document.getElementById('mfTr').click()); const hidden = await page.evaluate(() => Array.from(document.querySelectorAll('.mf-tr-layer')).every(l => getComputedStyle(l).display === 'none'));
    check('T26 switching off hides every box at once (the pictures are plain again)', hidden && await layers(page) >= 1);
    const askedBefore = ctx.asked.length; await page.evaluate(() => document.getElementById('mfTr').click());
    check('T27 switching on again shows the same boxes at once, with no new reading or asking', await page.evaluate(() => Array.from(document.querySelectorAll('.mf-tr-layer')).some(l => getComputedStyle(l).display === 'block')) && ctx.asked.length === askedBefore);
    // the language change: only the translation is repeated
    await page.evaluate(() => window.dispatchEvent(new CustomEvent('mf-settings-set', { detail: { trTo: 'hi' } })));
    let hi = true; try { await page.waitForFunction(() => Array.from(document.querySelectorAll('.mf-tr-b span')).some(s => /^TR\[hi\]/.test(s.textContent)), null, { timeout: 90000 }); } catch { hi = false; }
    check('T28 choosing Hindi translates again INTO Hindi (the service was asked with tl=hi)', hi && ctx.asked.some(a => a.tl === 'hi'), JSON.stringify(ctx.asked.slice(-2)));
    check('T29 the service was told the pages are English (sl=en)', ctx.asked.some(a => a.tl === 'hi' && a.sl === 'en'));
    check('T30 the small panel shows the new language', await page.evaluate(() => document.getElementById('mfTrTo').value === 'hi'));
    check('T31 no script error and no security-policy (CSP) refusal while the text reader ran', errs.length === 0 && csp.length === 0, errs.concat(csp).join(' | '));
    check('T32 the report for Troubleshoot contains the Translate lines', await page.evaluate(() => /Translate add-on/.test(window.MangaFlowTranslate.report()) && /pages: \d+ known/.test(window.MangaFlowTranslate.report())));
    await ctx.close(); }

  // ---------------------------------------------------------------- D. the old controls still work and do not collide with the new button
  for (const [label, opts] of [['computer', {}], ['phone', { touch: true, viewport: { width: 390, height: 800 } }]]) {
    const { ctx, page } = await open(opts); await read(page);
    const boxes = await page.evaluate(() => ['mfTr', 'mfWheel', 'mfEdge', 'mfSlider', 'dock'].map(id => { const e = document.getElementById(id); if (!e) return [id, null]; const r = e.getBoundingClientRect(); return [id, getComputedStyle(e).display === 'none' ? null : [r.left, r.top, r.right, r.bottom]]; }));
    const have = Object.fromEntries(boxes), t = have.mfTr; let clash = '';
    for (const id of ['mfWheel', 'mfEdge', 'mfSlider']) { const o = have[id]; if (t && o && !(t[2] <= o[0] || o[2] <= t[0] || t[3] <= o[1] || o[3] <= t[1])) clash += id + ' '; }
    check('T33 (' + label + ') the Translate button does not touch the wheel or the two sliders', !!t && !clash, clash + JSON.stringify(have));
    check('T34 (' + label + ') wheel, Top/End slider and chapter slider are all still there', await page.evaluate(() => !!window.MangaFlowWheel && !!window.MangaFlowEdge && !!window.MangaFlowSlider));
    await ctx.close(); }

  // ---------------------------------------------------------------- E. when things are missing or switched off
  { const { ctx, page } = await open({ settings: { showTranslate: false } }); await read(page);
    check('T35 the button is hidden when it is switched off in Settings', await page.evaluate(() => getComputedStyle(document.getElementById('mfTr')).display === 'none'));
    await ctx.close(); }
  { const { ctx, page } = await open({ route: async c => { await c.route('**/translate.js', r => r.abort()); } });
    check('T36 without translate.js the Settings tab and card are hidden and the reader still works', await page.evaluate(() => new Promise(ok => setTimeout(() => ok(document.body.classList.contains('no-tr-file') && getComputedStyle(document.querySelector('#setTabs [data-tab=translate]')).display === 'none' && !document.getElementById('mfTr')), 600))));
    await read(page); check('T37 reading mode works without translate.js', await page.evaluate(() => document.body.classList.contains('reading')));
    await ctx.close(); }
  { const { ctx, page } = await open({ route: async c => { await c.route('**/ocr/tesseract.min.js', r => r.abort()); } }); await read(page); await page.click('#mfTr');
    let bad = true; try { await page.waitForFunction(() => document.getElementById('mfTrBar').classList.contains('err'), null, { timeout: 30000 }); } catch { bad = false; }
    check('T38 missing reader files: the bar turns red and names the "ocr" folder (nothing else breaks)', bad && /ocr/.test(await page.evaluate(() => document.getElementById('mfTrMsg').textContent)));
    await page.click('#mfTrDet'); await page.waitForTimeout(300);
    check('T39 "Details" opens the big error box with a report that has the Translate lines', await page.evaluate(() => { const d = document.getElementById('errbox'); return d.open && /Translate add-on/.test(document.getElementById('errText').value); }));
    await ctx.close(); }
  { const { ctx, page } = await open({ route: async c => { await c.route('https://translate.googleapis.com/**', r => r.abort()); await c.route('https://api.mymemory.translated.net/**', r => r.abort()); } }); await read(page); await page.click('#mfTr');
    let bad = true; try { await page.waitForFunction(() => document.getElementById('mfTrBar').classList.contains('err'), null, { timeout: 120000 }); } catch { bad = false; }
    check('T40 no translation service reachable: a clear message (not a blank page), the old pictures stay', bad && /No translation service/.test(await page.evaluate(() => document.getElementById('mfTrMsg').textContent)) && await layers(page) === 0);
    await ctx.close(); }
  { const { ctx, page } = await open(); await page.click('#btnSettings'); await page.evaluate(() => { document.querySelector('#setTabs [data-tab=translate]').click(); });
    await page.click('#setTrTest'); await page.waitForFunction(() => /Translation works|✗ /.test(document.getElementById('trTestOut').textContent), null, { timeout: 60000 });
    const out = await page.evaluate(() => document.getElementById('trTestOut').textContent);
    check('T41 "Test translate" ticks all 10 reader files and shows that translation works', (out.match(/✓ ocr\//g) || []).length === 10 && /Translation works \(google/.test(out), out.slice(0, 400));
    await ctx.close(); }

  await browser.close();
  const failed = results.filter(r => !r.ok);
  console.log('\n' + (results.length - failed.length) + ' / ' + results.length + ' translate tests passed' + (failed.length ? '. FAILED: ' + failed.map(f => f.name.split(' ')[0]).join(', ') : '.'));
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
